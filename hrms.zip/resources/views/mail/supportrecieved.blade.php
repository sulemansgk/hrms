@extends("mail.layout")
@section("email_content")
Hi {{ $name }},
<br/><br/>
Thank you for contacting HRM Team. We have received your request and will get back to you as soon as possible.
<br/><br/>
@endsection
