@extends("emails.site.layout")
@section("email_content")
    @lang('email.hi'),
    <br/><br/>
    @lang('email.testEmailText')
    <br/><br/>

@endsection
