@extends("mail.layout")
@section("email_content")
    {!! $body !!}
@endsection

