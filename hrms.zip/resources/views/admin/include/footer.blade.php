<!-- BEGIN FOOTER -->
<div class="page-footer">
	<div class="page-footer-inner">

		{{--{{date('Y')}} &copy;  <a href="http://www.hrm.com" target="_blank">{{HTML::image("assets/admin/layout/img/logo-HRM.png",'Logo',array('class'=>'logo-default','height'=>'13px'))}}</a>--}}
	</div>
	<div class="scroll-to-top">
		<i class="icon-arrow-up"></i>
	</div>
</div>
<!-- END FOOTER -->