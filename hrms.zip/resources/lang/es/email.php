<?php

return [

		'hi'                    =>  'Hola',
	//Admin and employee add
		'yourAccountCreated'    => 'Tu cuenta ha sido creada en',
		'loginDetailBelow'      =>  'Tus detalles de acceso son los siguientes:',
		'tryLogging'            =>  'Intenta ingresar en ',

	//Attendance Marked
		'yourAttendanceDate'    =>  ' Tu asistencia para la fecha',
		'hasBeenMarked'         =>  ' ha sido marcada',

	//Awards
		'awarded'               =>   '<strong>¡Felicidades,</strong> has recibido un premio!',

	//Expense
		'expense'               =>  'Tu reclamo de gastos fechado el <strong>:attributeDate </strong> ha sido <strong>:attributeStatus</strong>',

	//NoticeBoard
		'newNotice'            =>  'Nuevo aviso publicado. Por favor revisa tu tablero. Haz clic aquí :attribute to go to dashboard',

	//Front End
		'passwordReset'       => 'Tu contraseña ha sido reestablecida exitósamente.',

	//expense submitted
		'expenseSubmitted'    =>  'enviado un gasto nuevo',
		'resumeSubmitted'    =>   'enviado un nuevo curriculum',

	//leave Apply
		'appliedLeave'      =>  'Solicitado un Permiso'
];
