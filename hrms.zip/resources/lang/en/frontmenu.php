<?php
return [
    'Pricing' => 'Pricing',
    'Features' => 'Features',
    'TermsofService' => 'Terms of Service',
    'PrivacyPolicy' => 'Privacy Policy',
    'ContactUs' => 'Contact Us',
    'Support' => 'Support',
    'Login' => 'Login',
    'SignUp' => 'Sign Up',
];
