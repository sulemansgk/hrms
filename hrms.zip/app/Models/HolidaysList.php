<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HolidaysList extends Model
{

    protected $table = "holidays_list";

}
