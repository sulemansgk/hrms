<?php
    namespace App\Models;

    class Country extends BaseModel
    {
        protected $fillable = [];
    }
